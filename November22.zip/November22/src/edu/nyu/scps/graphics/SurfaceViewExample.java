package edu.nyu.scps.graphics;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;

public class SurfaceViewExample extends Activity implements OnTouchListener {
    
	/** Called when the activity is first created. */
	Ourview v;
	Bitmap ball;
	float x,y;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        v=new Ourview(this);
        v.setOnTouchListener(this);
        ball= BitmapFactory.decodeResource(getResources(), R.drawable.blackred);
        
        x =0;
        y =0;
        setContentView(v);
           
    }
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		v.pause();
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		v.resume();
	}
    public class Ourview extends SurfaceView implements Runnable{
    	Thread t=null;
    	SurfaceHolder holder;
    	boolean isItOk=false;
    	
    	public Ourview (Context context){
    		super(context);
    		holder=getHolder();
    	}
    	public void run(){
    		while(isItOk==true){
    			//canvas drawing
    			if(!holder.getSurface().isValid()){
    				continue;
    			}
    			
    			Canvas c=holder.lockCanvas();
    			//c.drawARGB(255, 150, 150, 10);
    			c.drawBitmap(ball,x-(ball.getWidth()/2), y-(ball.getHeight()/2),new Paint());
    			holder.unlockCanvasAndPost(c);
    			
    		}
    	}
    	public void pause(){
    		isItOk=false;
    		while(true){
    			try{
    				t.join();
    			}
    			catch(InterruptedException e){
    				e.printStackTrace();
    			}
    			break;
    		}
    		t=null;
    	}
    	public void resume(){
    		isItOk=true;
    		t=new Thread(this);
    		t.start();
    	}
    	
    }
   
   
    
	@Override
	public boolean onTouch(View v, MotionEvent me) {
		// TODO Auto-generated method stub
		try{
			Thread.sleep(50);
		}
		catch(InterruptedException e){
			e.printStackTrace();
			
		}
		
		switch( me.getAction()){
		case MotionEvent.ACTION_DOWN:
			x = me.getX();
			y = me.getY();
			
			break;
		case MotionEvent.ACTION_UP:
			x = me.getX();
			y = me.getY();
			
			break;
		case MotionEvent.ACTION_MOVE:
			x = me.getX();
			y = me.getY();
			
			
			break;
		
			
		}
		return true;
	}
    	
    
}   
