package edu.nyu.scps.homework.one;

import java.util.Random;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity  implements View.OnClickListener {
    /** Called when the activity is first created. */
	 EditText editTextView;
      @Override
    
       public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);       
             
        Button buttonChange = (Button)findViewById(R.id.change);  
       // LinearLayout mScreen = (LinearLayout) findViewById(R.id.myScreen);
        buttonChange.setOnClickListener(this);
        Button inputData=(Button)findViewById(R.id.button1);
        inputData.setOnClickListener(this);
    			}
    
    @Override
	public void onClick(View v) {    	
    	int color;
    	switch(v.getId()){
    	case R.id.change:
    	
    	LinearLayout mScreen = (LinearLayout) findViewById(R.id.myScreen);
    	
	    Random rnd = new Random(); 
	    color = Color.argb(255, rnd.nextInt(255), rnd.nextInt(255), rnd.nextInt(255));   
	    (mScreen).setBackgroundColor(color);
	    break;
    	case R.id.button1:
    		
    		editTextView = (EditText) findViewById(R.id.editText1);
            String name = editTextView.getText().toString();
            TextView outString = (TextView) findViewById(R.id.TextOut);
            outString.setText("Thanks for the info:"+name);
            
	}
    
}
}
