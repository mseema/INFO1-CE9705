package edu.nyu.scps.dialog;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);    	
        setContentView(R.layout.main);
        final Button button = (Button)findViewById(R.id.alertDialog);

		
    }
    public  void showAlert(View view){
    	new AlertDialog.Builder(this)
    	.setTitle("MessageDemo")
    	.setMessage("Let's raise a toast!")
    	.setNeutralButton("Click here!", new DialogInterface.OnClickListener() {
    	
			@Override
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this,"Happy Holidays!!",Toast.LENGTH_SHORT).show();				
			}
		})
		.show();
    	
    }
}