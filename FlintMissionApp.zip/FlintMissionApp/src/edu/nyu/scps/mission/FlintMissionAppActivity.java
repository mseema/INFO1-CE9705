package edu.nyu.scps.mission;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class FlintMissionAppActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);   
        
      //Parameters common to all or most of my layouts.
      		final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
      			ViewGroup.LayoutParams.WRAP_CONTENT,		//width
      			ViewGroup.LayoutParams.WRAP_CONTENT,	//height
      			0.0f									//weight
      		);

      		//Parameters common to all or most of my widgets.
      		final LinearLayout.LayoutParams widgetParams = new LinearLayout.LayoutParams(
      			ViewGroup.LayoutParams.WRAP_CONTENT,	//width
      			ViewGroup.LayoutParams.WRAP_CONTENT,	//height
      			0.0f									//weight
      		);
        
        final TextView counter = (TextView) findViewById(R.id.counter);
		
		final Handler handler = new Handler() {
			@Override
			public void handleMessage(Message message) {
				if (message.what == 999999)
						counter.setText("Counter : "+Integer.toString(message.arg1));
			}
		};
	    
		final MyThread myThread = new MyThread(handler);
		myThread.start();
        
        final LinearLayout root = (LinearLayout) findViewById(R.id.myscreen);        
        final Button goMissionButton = (Button) findViewById(R.id.operationbutton);
         
        goMissionButton.setOnClickListener(new OnClickListener() {        	
			@Override
			public void onClick(View v) {			
				final EditText oppName = (EditText) findViewById(R.id.operationname);
				final TextView oppTitleDiscription = new TextView(FlintMissionAppActivity.this);

				{					
					oppTitleDiscription.setText("Your Mission Started : "+oppName.getText().toString());
				}

				root.addView(oppTitleDiscription, 5);
				final TextView country = new TextView(FlintMissionAppActivity.this);

				{					
					country.setText("Choose a country where mission is based : ");
				}
				root.addView(country, 6);
				
						
				Spinner spinner = new Spinner(FlintMissionAppActivity.this);
				root.addView(spinner, 7);				
			    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
			    		FlintMissionAppActivity.this, R.array.country_array, android.R.layout.simple_spinner_item);
			    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			    spinner.setAdapter(adapter);
				
			}
		}); 
      //CheckBox

      		final CheckBox checkBox = new CheckBox(this);
      		checkBox.setLayoutParams(widgetParams);
      		checkBox.setText("Details Of The Mission");

      		checkBox.setOnClickListener(new OnClickListener() {
      			@Override
      			public void onClick(View v) {
      				String s = checkBox.isChecked() ? "Checked" : "Unchecked";
      				Toast.makeText(FlintMissionAppActivity.this,"Call 123-456-7890" , Toast.LENGTH_LONG).show();
      			}
      		});

      		root.addView(checkBox);
      		

    		// Radio buttons. 
    		
    		RadioGroup radioGroup = new RadioGroup(this);
    		radioGroup.setLayoutParams(layoutParams);
    		radioGroup.setOrientation(LinearLayout.VERTICAL);
    		radioGroup.setBackgroundColor(0xFF800000);	//alpha (FF) required
    		
    		root.addView(radioGroup);

    		

    		final RadioButton radioButton0 = new RadioButton(this);
    		radioButton0.setLayoutParams(widgetParams);
    		radioButton0.setText("Mission Starts Now");
    		radioButton0.setOnClickListener(new OnClickListener(){
    			public void onClick(View v) {
    				
                    Toast.makeText(FlintMissionAppActivity.this, "All The Best!!", Toast.LENGTH_SHORT).show();
    			}
    			
    		});
    		radioGroup.addView(radioButton0);

    		final RadioButton radioButton1 = new RadioButton(this);
    		radioButton1.setLayoutParams(widgetParams);
    		radioButton1.setText("Mission Starts Later");
    		radioButton1.setOnClickListener(new OnClickListener(){
                public void onClick(View v) {
    				
                    Toast.makeText(FlintMissionAppActivity.this, "See You Later!!", Toast.LENGTH_SHORT).show();
    			}
    			
    		});
    		radioGroup.addView(radioButton1);

    		};

    		       
       
    
    
    final class MyThread extends Thread{
    	final Handler handler;    	

    	MyThread(Handler handler) {
    		this.handler = handler;
    	}
           
    	@Override
    	public void run() {
    		int i= 0;
    		for (;;) {
    			try {
    				//1000 milliseconds == 1 second
    				Thread.sleep(1000);    				
    			} catch (InterruptedException e) {
    				Log.e("ERROR", "Thread Interrupted");
    			}
     
    			final Message message = handler.obtainMessage(999999); //Get an empty Message.
    			
    			message.arg1 = i++;//Fill it up.
    			
    			//Send the mesage to the Handler.
    			//Calls handleMessage, below.
    			handler.sendMessage(message);
    		}
    	}
    }
}